/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codearea;

/**
 *
 * @author joseph
 */
import javafx.scene.layout.StackPane;
import javafx.scene.web.WebView;

/**
 * A syntax highlighting code editor for JavaFX created by wrapping a
 * CodeMirror code editor in a WebView.
 *
 * See http://codemirror.net for more information on using the codemirror editor.
 */
public class CodeEditor extends StackPane {
  /** a webview used to encapsulate the CodeMirror JavaScript. */
  final WebView webview = new WebView();

  /** a snapshot of the code to be edited kept for easy initilization and reversion of editable code. */
  private String editingCode;

  /**
   * a template for editing code - this can be changed to any template derived from the
   * supported modes at http://codemirror.net to allow syntax highlighted editing of
   * a wide variety of languages.
   */
  private final String editingTemplate =
    "<!doctype html>" +
    "<html>" +
    "<head>" +
    "  <link rel=\"stylesheet\" href=\"http://localhost:400/lib/codemirror.css\">" +
    "  <script src=\"http://localhost:400/lib/codemirror.js\"></script>" +
    "  <script src=\"http://localhost:400/lib/jquery.js\"></script>" +
          
    "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/base16-light.css\">" +
    "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/idea.css\">" +
    "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/eclipse.css\">" + 
    "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/tomorrow-night-eighties.css\">" +
          
    "  <script src=\"http://localhost:400/mode/clike/clike.js\"></script>" +
          
    "  <script src=\"http://localhost:400/mode/javascript/javascript.js\"></script>" +
    "  <script src=\"http://localhost:400/addon/selection/active-line.js\"></script>" +
    "  <script src=\"http://localhost:400/addon/edit/matchbrackets.js\"></script>" +
    "  <script src=\"http://localhost:400/addon/selection/mark-selection.js\"></script>" +
    "  <script src=\"http://localhost:400/addon/search/searchcursor.js\"></script>" +
//    "  <script src=\"http://localhost:400/addon/edit/closetag.js\"></script>" +
    "  <script src=\"http://localhost:400/addon/selection/selection-pointer.js\"></script>" + 
          
    "<style>\n" +
"      .CodeMirror {border-top: 1px solid black; border-bottom: 1px solid black;}\n" +
"      .CodeMirror-selected  { background-color: blue !important; }\n" +
"      .CodeMirror-selectedtext { color: white; }\n" +
"      .styled-background { background-color: #ff7; }\n"+ 
"      .breakpoints {width: .8em;}\n" +
"      .breakpoint { color: #822; }\n" +
"      .CodeMirror {border: 1px solid #aaa;}" +
"    </style>"+
    "<script>"+
    "var   i=1;" +
    "function mostrar() {\n" +
    "  i++;\n" +
    "  editor.addLineClass(i, 'wrap', 'CodeMirror-activeline-error');" +  
    "  alert(\"hola prros\");\n" +
    "  editor.markText({line: 3, ch: 2}, {line: 3, ch: 7}, {className: \"styled-background\"});" +
    "   return \"hola viejo\";"+
    //"   editor.setLineClass(2, 'background', 'line-error');"+
    "}"+
    "</script>"+
    "</head>" +
          
    "<body onload=\"mostrar();\">" +
    "<form><textarea id=\"code\" name=\"code\">\n" +
    "${code}" +
    "</textarea></form>" +
    "<script>" +
          
    "  var editor = CodeMirror.fromTextArea(document.getElementById(\"code\"), {" +
    "    lineNumbers: true," +
    "    matchBrackets: true," +
    "    mode: \"text/x-java\"," +
//    "    theme: \"eclipse\","+
//    "    theme: \"base16-light\","+
//    "    theme: \"tomorrow-night-eighties\","+
    "    indentWithTabs:true, "+
    "    lineWrapping: true, "+
    "    gutters: [\"CodeMirror-linenumbers\", \"breakpoints\"], "+
    "    styleSelectedText: true, "+
    "    styleActiveLine: true "+
          
    "  });" +  
          
   
    "editor.on(\"gutterClick\", function(cm, n) {\n" +
    "  i++;\n" +
    "  var info = cm.lineInfo(n);\n" +
    "  cm.setGutterMarker(n, \"breakpoints\", info.gutterMarkers ? null : makeMarker());\n" +
    "});\n" +
    "\n" +
    "function makeMarker() {\n" +
    "  var marker = document.createElement(\"div\");\n" +
    "  marker.style.color = \"#822\";\n" +
    "  marker.innerHTML = \"●\";\n" +
    "  return marker;\n" +
    "}"+
    "</script>" +
    "</body>" +
    "</html>";

  
  
  /** applies the editing template to the editing code to create the html+javascript source for a code editor. */
  private String applyEditingTemplate() {
    return editingTemplate.replace("${code}", editingCode);
  }

  /** sets the current code in the editor and creates an editing snapshot of the code which can be reverted to.
     * @param newCode */
  public void setCode(String newCode) {
    this.editingCode = newCode;
    webview.getEngine().loadContent(applyEditingTemplate());
  }

  /** returns the current code in the editor and updates an editing snapshot of the code which can be reverted to.
     * @return  */
  public String getCodeAndSnapshot() {
    this.editingCode = (String ) webview.getEngine().executeScript("editor.getValue();");
    
    String prueba = (String ) webview.getEngine().executeScript("mostrar();"); 
      System.out.println("=============");
      System.out.println(prueba);
    return editingCode;
  }

  /** revert edits of the code to the last edit snapshot taken. */
  public void revertEdits() {
    //setCode(editingCode);
    webview.getEngine().executeScript("editor.markText({line: 1, ch: 1}, {line: 3, ch: 4}, {className: \"styled-background\"});");
  }

  /**
   * Create a new code editor.
   * @param editingCode the initial code to be edited in the code editor.
   */
  CodeEditor(String editingCode) {
    this.editingCode = editingCode;

    webview.setPrefSize(650, 325);
    webview.setMinSize(650, 325);
    webview.getEngine().loadContent(applyEditingTemplate());

    this.getChildren().add(webview);
  }
  
  public void cadena(){
      
        String editingTemplate2
                = "<!doctype html>"
                + "<html>"
                + "<head>"
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/lib/codemirror.css\">"
                + "  <script src=\"http://localhost:400/lib/codemirror.js\"></script>"
                + "  <script src=\"http://localhost:400/lib/jquery.js\"></script>"
                
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/base16-light.css\">"
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/idea.css\">"
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/eclipse.css\">"
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/tomorrow-night-eighties.css\">"
                + "  <link rel=\"stylesheet\" href=\"http://localhost:400/theme/darcula.css\">"
                
                
                + "  <script src=\"http://localhost:400/mode/clike/clike.js\"></script>"
                + "  <script src=\"http://localhost:400/mode/javascript/javascript.js\"></script>"
                + "  <script src=\"http://localhost:400/addon/selection/active-line.js\"></script>"
                + "  <script src=\"http://localhost:400/addon/edit/matchbrackets.js\"></script>"
                + "  <script src=\"http://localhost:400/addon/selection/mark-selection.js\"></script>"
                + "  <script src=\"http://localhost:400/addon/search/searchcursor.js\"></script>"
                + //    "  <script src=\"http://localhost:400/addon/edit/closetag.js\"></script>" +
                "  <script src=\"http://localhost:400/addon/selection/selection-pointer.js\"></script>"
                + "<style>\n"
//                + "      .CodeMirror {border-top: 1px solid black; border-bottom: 1px solid black;}\n"
//                + "      .CodeMirror-selected  { background-color: blue !important; }\n"
//                + "      .CodeMirror-selectedtext { color: white; }\n"
//                + "      .styled-background { background-color: #ff7; }\n"
                + "      .breakpoints {width: .8em;}\n"
                + "      .breakpoint { color: #822; }\n"
                + "      .CodeMirror {border: 1px solid #aaa;}"
                + "    </style>"
                + "<script>"
                + "var   i=1;"
                + "function mostrar() {\n"
                + "  i++;\n"
//                + "  editor.addLineClass(i, 'wrap', 'CodeMirror-activeline-error');"
                + "  alert(\"hola prros\");\n"
                + "  editor.markText({line: 3, ch: 2}, {line: 3, ch: 7}, {className: \"styled-background\"});"
                + "   return \"hola viejo\";"
                + //"   editor.setLineClass(2, 'background', 'line-error');"+
                "}"
                + "</script>"
                + "</head>"
                + "<body onload=\"mostrar();\">"
                + "<form><textarea id=\"code\" name=\"code\">\n"
                + "${code}"
                + "</textarea></form>"
                + "<script>"
                + "  var editor = CodeMirror.fromTextArea(document.getElementById(\"code\"), {"
                + "    lineNumbers: true,"
                + "    matchBrackets: true,"
                + "    viewportMargin: Infinity,"
                
//                + "    mode: \"text/x-java\","
                + "    mode: \"text/javascript\","
                + "    theme: \"eclipse\"," 
//                + "    theme: \"darcula\","
//                +    "    theme: \"base16-light\","
                //    "    theme: \"tomorrow-night-eighties\","+
                + "    indentWithTabs:true, "
                + "    lineWrapping: true, "
                
                + "    tabSize: 4, "
                + "    gutters: [\"CodeMirror-linenumbers\", \"breakpoints\"], "
                + "    styleSelectedText: true, "
                + "    styleActiveLine: true "
                + "  });"
                + "editor.on(\"gutterClick\", function(cm, n) {\n"
                + "  i++;\n"
                + "  var info = cm.lineInfo(n);\n"
                + "  cm.setGutterMarker(n, \"breakpoints\", info.gutterMarkers ? null : makeMarker());\n"
                + "});\n"
                + "\n"
                + "function makeMarker() {\n"
                + "  var marker = document.createElement(\"div\");\n"
                + "  marker.style.color = \"#822\";\n"
                + "  marker.innerHTML = \"●\";\n"
                + "  return marker;\n"
                + "}"
                + "</script>"
                + "</body>"
                + "</html>";
        
        
  }
}